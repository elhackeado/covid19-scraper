<!--
https://pypi.org/project/readme-generator/
https://pypi.org/project/python-readme-generator/
-->

[![](https://img.shields.io/pypi/pyversions/public.svg?longCache=True)](https://pypi.org/project/public/)

#### Installation
```bash
$ [sudo] pip install public
```

#### Features
+   replace [`__all__`](https://stackoverflow.com/questions/44834/can-someone-explain-all-in-python) with `@public.add` decorator


before
```python
__all__ = ["func"]

def func():
```

after
```python
import public

@public.add
def func():
```

#### Functions
function|`__doc__`
-|-
`public.add(*objects)` |add objects to `__all__`
`public.public(*objects)` |add objects to `__all__`. deprecated
`public.test(module)` |test module `__all__`

#### Examples
```python
>>> import public
>>> @public.add
    def func(): pass

>>> @public.add
    class Cls: pass

>>> __all__
['Cls','func']

>>> public.add("name")
>>> public.add(*["name1","name2"])

>>> __all__
['Cls','func','name','name1','name2']
```

#### Links
+   [Importing * From a Package. Python documentation](https://docs.python.org/3/tutorial/modules.html#importing-from-a-package)
+   [Can someone explain __all__ in Python? Stackoverflow](https://stackoverflow.com/questions/44834/can-someone-explain-all-in-python)

<p align="center">
    <a href="https://pypi.org/project/python-readme-generator/">python-readme-generator</a>
</p>

